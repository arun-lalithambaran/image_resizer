import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PhotoAlbumPageComponent } from './components/photo-album-page/photo-album-page.component';
import { Routes, RouterModule } from '@angular/router';
import { ThemeComponentComponent } from './components/theme-component/theme-component.component';
import { LayoutComponentComponent } from './components/layout-component/layout-component.component';
import { ImageComponentComponent } from './components/image-component/image-component.component';
import { PhotoBookComponentComponent } from './components/photo-book-component/photo-book-component.component';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { HeaderComponent } from './components/header/header.component';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

const routes: Routes = [
  { pathMatch: 'full', path: '', component: PhotoAlbumPageComponent },
  { pathMatch: 'full', path: 'create-photo-book', component: PhotoBookComponentComponent },
];

@NgModule({
  declarations: [PhotoAlbumPageComponent, ThemeComponentComponent, LayoutComponentComponent, ImageComponentComponent, PhotoBookComponentComponent, LandingPageComponent, HeaderComponent, SideBarComponent],
  imports: [
    SelectDropDownModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule.forChild(routes),
    PopoverModule.forRoot(),
  ]
})
export class PhotoAlbumModule { }
