import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { MainRestService } from 'src/app/shared/Knottfar/main.rest';
import { AlbumService } from '../../services/album.service';
import { IPriceMap, IAlbumSettings, IAlbumProperty, IAlbumSettingsAPIResponse, IAlbumOriantaionConfig } from '../../interfaces/album-settings.d';
import { FormGroup, FormControl } from '@angular/forms';
import { StaticConstants } from 'src/app/shared/utils/static';

@Component({
  selector: 'app-photo-album-page',
  templateUrl: './photo-album-page.component.html',
  styleUrls: ['./photo-album-page.component.scss']
})
export class PhotoAlbumPageComponent implements OnInit {
  private apiResponse: IAlbumSettingsAPIResponse;
  private orientationList = new Set();
  public sheetPrice: number;
  public coverPrice: number;
  public orientationMap = { landscape: 1, square: 2, portrait: 3 }

  public paperSzeSelectDropdownConfig = new StaticConstants().selectConfig('albumPaperSize', 'Select');
  public coverSelectDropdownConfig = new StaticConstants().selectConfig('albumCoverName', 'Select');
  public paperTypeSelectDropdownConfig = new StaticConstants().selectConfig('albumPaperType', 'Select');

  public albumSettingsForm: FormGroup;
  public orientation: FormControl;
  public paperSize: FormControl;
  public cover: FormControl;
  public paperType: FormControl;
  public sheetCount: FormControl;

  public activeListItems: IAlbumOriantaionConfig = {
    albumType: [],
    paperSize: [],
    covers: [],
    paperType: []
  }

  private priceMap: IPriceMap = {};
  private albumSettings: IAlbumSettings = {
    landescape: {
      albumType: [],
      paperSize: [],
      covers: [],
      paperType: []
    },
    square: {
      albumType: [],
      paperSize: [],
      covers: [],
      paperType: []
    },
    portrait: {
      albumType: [],
      paperSize: [],
      covers: [],
      paperType: []
    }
  }

  constructor(
    private restService: MainRestService,
    private albumService: AlbumService
  ) { }

  ngOnInit() {
    this.createForm();
    this.albumService.getAlbumSettingsData().then(res => {
      this.apiResponse = res;
      this.processAlbumSettings(res);
      this.paperSize.valueChanges.subscribe(change => {
        console.log('new value', change);
      })
    })
    // this.restService.homePage1().then((data: any) => {

    // }). catch((err: HttpErrorResponse) => {
    //   console.log(err);
    // });

    this.orientation.valueChanges.subscribe(newValue => {
      console.log('new value', newValue)
      this.orientationChange();
    })
    

    //For debug purpose only
    window['albumDebug'] = () => {
      console.log('album settings and priceMap', {
        processedList: this.albumSettings,
        mapList: this.priceMap,
        orientationList: this.orientationList
      })
      console.log('active list items', this.activeListItems)
      console.log('form controls', this.albumSettingsForm.value);
      console.log('coverPrice: ', this.coverPrice, 'sheetPrice: ', this.sheetPrice)
    }
  }
  public createForm() {
    this.orientation = new FormControl('');
    this.paperSize = new FormControl('');
    this.cover = new FormControl('');
    this.paperType = new FormControl('');
    this.sheetCount = new FormControl(0);

    this.albumSettingsForm = new FormGroup({
      orientation: this.orientation,
      paperSize: this.paperSize,
      cover: this.cover,
      paperType: this.paperType,
      sheetCount: this.sheetCount
    })
  }
  public selectDropdownChange(event) {
    this.updateDropDownList();
    this.updateDisplayPrice();
  }
  public processAlbumSettings(API_Response: IAlbumSettingsAPIResponse) {

    API_Response.data.forEach(albumProperty => {
      this.orientationList.add(albumProperty.albumType.albumTypeId);
      switch (albumProperty.albumType.albumTypeId) {
        case 1: {
          if (!this.checkArrayItemExistence(this.albumSettings.landescape.albumType, albumProperty.albumType, 'albumTypeId'))
            this.albumSettings.landescape.albumType.push(albumProperty.albumType);
          if (!this.checkArrayItemExistence(this.albumSettings.landescape.paperSize, albumProperty.albumPaperSize, 'albumPaperSizeId'))
            this.albumSettings.landescape.paperSize.push(albumProperty.albumPaperSize);
          if (!this.checkArrayItemExistence(this.albumSettings.landescape.paperType, albumProperty.albumPaperType, 'albumPaperTypeId'))
            this.albumSettings.landescape.paperType.push(albumProperty.albumPaperType);
          if (!this.checkArrayItemExistence(this.albumSettings.landescape.covers, albumProperty.albumCover, 'albumCoverId'))
            this.albumSettings.landescape.covers.push(albumProperty.albumCover);
          break;
        }
        case 2: {
          if (!this.checkArrayItemExistence(this.albumSettings.square.albumType, albumProperty.albumType, 'albumTypeId'))
            this.albumSettings.square.albumType.push(albumProperty.albumType);
          if (!this.checkArrayItemExistence(this.albumSettings.square.paperSize, albumProperty.albumPaperSize, 'albumPaperSizeId'))
            this.albumSettings.square.paperSize.push(albumProperty.albumPaperSize);
          if (!this.checkArrayItemExistence(this.albumSettings.square.paperType, albumProperty.albumPaperType, 'albumPaperTypeId'))
            this.albumSettings.square.paperType.push(albumProperty.albumPaperType);
          if (!this.checkArrayItemExistence(this.albumSettings.square.covers, albumProperty.albumCover, 'albumCoverId'))
            this.albumSettings.square.covers.push(albumProperty.albumCover);
          break;
        }
        case 3: {
          if (!this.checkArrayItemExistence(this.albumSettings.portrait.albumType, albumProperty.albumType, 'albumTypeId'))
            this.albumSettings.portrait.albumType.push(albumProperty.albumType);
          if (!this.checkArrayItemExistence(this.albumSettings.portrait.paperSize, albumProperty.albumPaperSize, 'albumPaperSizeId'))
            this.albumSettings.portrait.paperSize.push(albumProperty.albumPaperSize);
          if (!this.checkArrayItemExistence(this.albumSettings.portrait.paperType, albumProperty.albumPaperType, 'albumPaperTypeId'))
            this.albumSettings.portrait.paperType.push(albumProperty.albumPaperType);
          if (!this.checkArrayItemExistence(this.albumSettings.portrait.covers, albumProperty.albumCover, 'albumCoverId'))
            this.albumSettings.portrait.covers.push(albumProperty.albumCover);
          break;
        }
      }
      this.priceMap[this.generatepriceMapKey(albumProperty)] = {
        coverPrice: albumProperty.coverPrice,
        sheetPrice: albumProperty.sheetPrice
      }
    })
    if (this.orientationList.size > 0) {
      this.orientation.setValue(Array.from(this.orientationList)[0]);
      this.orientationChange();
    }

  }
  private checkArrayItemExistence(array: any[], value: any, key: string): boolean {
    if (array.findIndex(item => item[key] === value[key]) === -1) {
      return false;
    } else {
      return true;
    }
  }
  public orientationChange() {
    switch (this.orientation.value) {
      case 1: {
        this.activeListItems = this.albumSettings.landescape;
        break;
      }
      case 2: {
        this.activeListItems = this.albumSettings.square;
        break;
      }
      case 3: {
        this.activeListItems = this.albumSettings.portrait;
        break;
      }
    }
    this.initializeFormControls();
  }
  private updateDropDownList() {

  }
  private initializeFormControls() {
    this.paperSize.setValue(this.activeListItems.paperSize[0] ? this.activeListItems.paperSize[0] : '');
    this.cover.setValue(this.activeListItems.covers[0] ? this.activeListItems.covers[0] : '');
    this.paperType.setValue(this.activeListItems.paperType[0] ? this.activeListItems.paperType[0] : '');
    this.updateDisplayPrice();
  }
  private updateDisplayPrice() {
    let key = this.generatepriceMapKey();
    this.coverPrice = this.priceMap[key].coverPrice;
    this.sheetPrice = this.priceMap[key].sheetPrice;
  }
  private generatepriceMapKey(albumProperty?: IAlbumProperty): string {
    let mapKey = '';
    if (albumProperty === undefined) {
      mapKey += (this.orientation.value + '') +
        (this.paperType.value.albumPaperTypeId + '') +
        (this.paperSize.value.albumPaperSizeId + '') +
        (this.cover.value.albumCoverId + '')
    } else {
      mapKey += `${albumProperty.albumType.albumTypeId}${albumProperty.albumPaperType.albumPaperTypeId}${albumProperty.albumPaperSize.albumPaperSizeId}${albumProperty.albumCover.albumCoverId}`;
    }
    console.log(mapKey)
    return mapKey;
  }

}
