import { Component, OnInit } from '@angular/core';
import { RootService } from '../../services/root-Store/root.service';
import { ChannelService } from '../../services/channel-service/channel.service';


@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.scss']
})
export class SideBarComponent implements OnInit {
  activeNavItem: any= false;
  constructor(
    public root:RootService,
    private channel: ChannelService,
    ) { }

  ngOnInit() {
    this.activeNavItem = this.root.selectedNavItem;
  }
  public navClick(navItem: any) {
    this.channel.selectedNavUpdate.next(navItem);
    this.activeNavItem = navItem;
  //  this.root.selectedNavItem = navItem;
}

}
