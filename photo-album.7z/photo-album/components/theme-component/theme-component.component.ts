import { Component, OnInit } from '@angular/core';
import { PhpRestService } from 'src/app/shared/Knottfar/php.rest';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-theme-component',
  templateUrl: './theme-component.component.html',
  styleUrls: ['./theme-component.component.scss']
})
export class ThemeComponentComponent implements OnInit {
  public themeList    : any = [];
  public categoryList : any = [];
  public themeToggle  : any = false;
  public themeAPICall : any = true;
  constructor(
    private restService: PhpRestService
  ) { 

  }

  ngOnInit() {
    this.restService.masterThemeCategory().then((data: any) => {
     if(data){
       this.categoryList = data;
     }
     
    }). catch((err: HttpErrorResponse) => {
      console.log(err);
    });
  }
  public categoryClick(category){
    this.themeToggle = !this.themeToggle;
    if(this.themeAPICall){
      this.restService.albumTheme(category.albumThemeCatId).then((data: any) => {
        this.themeList = data;
        this.themeAPICall = false;
       }). catch((err: HttpErrorResponse) => {
         console.log(err);
       });
    }
  }
  public themeClick(themeClass){
    console.log(themeClass);

  }
  public closePopover(){
    this.themeToggle = false;
  }

}
