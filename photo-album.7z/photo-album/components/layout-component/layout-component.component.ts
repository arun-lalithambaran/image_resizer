import { Component, OnInit } from '@angular/core';
import { PhpRestService } from 'src/app/shared/Knottfar/php.rest';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-layout-component',
  templateUrl: './layout-component.component.html',
  styleUrls: ['./layout-component.component.scss']
})
export class LayoutComponentComponent implements OnInit {
  public layoutList: any = [];
  public subLayoutList:any = [];
  public contentList: any = [];
  public imageSectionClass: any = '';
  public boxCount:any = 0;
  constructor(
    private restService: PhpRestService
  ) { }

  ngOnInit() {
    this.restService.albumLayout().then((data: any) => {
      if (data) {
        this.processData(data)
      }

    }).catch((err: HttpErrorResponse) => {
      console.log(err);
    });
  }
  processData(data){
    let array = data.filter((v,i) => data.findIndex(item => item.layoutBoxCount == v.layoutBoxCount) === i);
        this.layoutList = array.sort(function(a, b){
          return a.layoutBoxCount-b.layoutBoxCount
      });
    //   this.layoutList.forEach((tblRow) => {
    //     tblRow.active = true;
    // });
    this.layoutList[0].active = true;

        this.subLayoutList = this.layoutList.filter((rowItem: any) => rowItem.layoutBoxCount== 1);
        this.contentList = ['1'];
  }

  public smallLayoutClick(item) {
    this.layoutList.forEach((tblRow) => {
      tblRow.active = false;
  });
    item.active = true;
    this.contentList = [];
    this.boxCount = item.layoutBoxCount;
    for (var i = 1; i <= this.boxCount; i++) {
      this.contentList.push(i);
   }
    this.subLayoutList = this.layoutList.filter((rowItem: any) => rowItem.layoutBoxCount== this.boxCount);
  }

}
