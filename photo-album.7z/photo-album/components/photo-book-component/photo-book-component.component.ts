import { Component, OnInit } from '@angular/core';
import { RootService } from '../../services/root-Store/root.service';
import { ChannelService } from '../../services/channel-service/channel.service';


@Component({
  selector: 'app-photo-book-component',
  templateUrl: './photo-book-component.component.html',
  styleUrls: ['./photo-book-component.component.scss']
})
export class PhotoBookComponentComponent implements OnInit {
//   public navItems = [
//     {order: 1, id: 'THEAMES', title: 'THEAMES'},
//     {order: 2, id: 'IMAGES', title: 'IMAGES'},
//     {order: 3, id: 'LAYOUTS', title: 'LAYOUTS'},
// ];
public SubscriptionDir:any;
public selectedNavItem: string;
  constructor(
    public root:RootService,
    private channel: ChannelService,
    ) { }

  ngOnInit() {
    this.selectedNavItem = this.root.selectedNavItem;
    this.SubscriptionDir = this.channel.selectedNavUpdate.subscribe((event) => {
      this.selectedNavItem = event;
    });
  }

}
