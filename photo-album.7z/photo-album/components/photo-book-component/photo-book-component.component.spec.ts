import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhotoBookComponentComponent } from './photo-book-component.component';

describe('PhotoBookComponentComponent', () => {
  let component: PhotoBookComponentComponent;
  let fixture: ComponentFixture<PhotoBookComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhotoBookComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhotoBookComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
