import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChannelService {
  public selectedNavUpdate: Subject<any>;

  constructor() {
    this.selectedNavUpdate = new Subject<any>();
   }
}
