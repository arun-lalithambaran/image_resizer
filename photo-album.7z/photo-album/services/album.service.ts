import { Injectable } from '@angular/core';
import { IAlbumSettingsAPIResponse } from '../interfaces/album-settings.d';

@Injectable({
  providedIn: 'root'
})
export class AlbumService {

  constructor() { }

  public getAlbumSettingsData(): Promise<IAlbumSettingsAPIResponse> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve({
          "data": [
            {
              "albumPropMapId": 2,
              "albumType": {
                "albumTypeId": 1,
                "albumType": "Landscape"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 1,
                "albumPaperSize": "30 x 40"
              },
              "albumCover": {
                "albumCoverId": 1,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 1,
              "sheetPrice": 1
            },
            {
              "albumPropMapId": 7,
              "albumType": {
                "albumTypeId": 2,
                "albumType": "Potrait"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 1,
                "albumPaperSize": "30 x 40"
              },
              "albumCover": {
                "albumCoverId": 1,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 11,
              "sheetPrice": 11
            },
            {
              "albumPropMapId": 14,
              "albumType": {
                "albumTypeId": 3,
                "albumType": "Square"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 1,
                "albumPaperSize": "30 x 40"
              },
              "albumCover": {
                "albumCoverId": 1,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 11,
              "sheetPrice": 5
            },
            {
              "albumPropMapId": 5,
              "albumType": {
                "albumTypeId": 1,
                "albumType": "Landscape"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 6,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 2,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 10,
              "sheetPrice": 10
            },
            {
              "albumPropMapId": 10,
              "albumType": {
                "albumTypeId": 2,
                "albumType": "Potrait"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 6,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 2,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 11,
              "sheetPrice": 11
            },
            {
              "albumPropMapId": 17,
              "albumType": {
                "albumTypeId": 3,
                "albumType": "Square"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 6,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 2,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 1,
                "albumPaperType": "Soft"
              },
              "coverPrice": 11,
              "sheetPrice": 5
            },
            {
              "albumPropMapId": 3,
              "albumType": {
                "albumTypeId": 1,
                "albumType": "Landscape"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 0,
                "albumPaperSize": null
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": null
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": null
              },
              "coverPrice": 10,
              "sheetPrice": 10
            },
            {
              "albumPropMapId": 4,
              "albumType": {
                "albumTypeId": 1,
                "albumType": "Landscape"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 2,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": null
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": null
              },
              "coverPrice": 10,
              "sheetPrice": 10
            },
            {
              "albumPropMapId": 8,
              "albumType": {
                "albumTypeId": 2,
                "albumType": "Potrait"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 0,
                "albumPaperSize": null
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": null
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": null
              },
              "coverPrice": 11,
              "sheetPrice": 11
            },
            {
              "albumPropMapId": 9,
              "albumType": {
                "albumTypeId": 2,
                "albumType": "Potrait"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 2,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": null
              },
              "coverPrice": 11,
              "sheetPrice": 11
            },
            {
              "albumPropMapId": 15,
              "albumType": {
                "albumTypeId": 3,
                "albumType": "Square"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 0,
                "albumPaperSize": '640 x 360'
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": "Strong Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": 'White paper'
              },
              "coverPrice": 110,
              "sheetPrice": 55
            },
            {
              "albumPropMapId": 16,
              "albumType": {
                "albumTypeId": 3,
                "albumType": "Square"
              },
              "albumPaperSize": {
                "albumPaperSizeId": 2,
                "albumPaperSize": "30x40"
              },
              "albumCover": {
                "albumCoverId": 0,
                "albumCoverName": "Hard Cover"
              },
              "albumPaperType": {
                "albumPaperTypeId": 0,
                "albumPaperType": null
              },
              "coverPrice": 11,
              "sheetPrice": 5
            }
          ],
          "count": 12
        })
      }, 2000)
    })
  }
}
