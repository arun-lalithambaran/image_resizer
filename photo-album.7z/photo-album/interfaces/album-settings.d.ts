export interface IAlbumSettingsAPIResponse {
    data: IAlbumProperty[];
    count: number;
}
export interface IAlbumProperty {
    "albumPropMapId": number;
    "albumType": IAlbumType;
    "albumPaperSize": IAlbumPaperSize;
    "albumCover": IAlbumCover;
    "albumPaperType": IAlbumPaperType;
    "coverPrice": number;
    "sheetPrice": number;
}
export interface IAlbumType {
    "albumTypeId": 1 | 2 | 3;
    "albumType": string | null;
}
export interface IAlbumPaperSize {
    "albumPaperSizeId": number;
    "albumPaperSize": string | null;
}
export interface IAlbumCover {
    "albumCoverId": number;
    "albumCoverName": string | null;
}
export interface IAlbumPaperType {
    "albumPaperTypeId": number;
    "albumPaperType": string | null;
}
export interface IAlbumSettings {
    "landescape": IAlbumOriantaionConfig;
    "square": IAlbumOriantaionConfig;
    "portrait": IAlbumOriantaionConfig;
}
export interface IAlbumOriantaionConfig {
    "albumType": IAlbumType[];
    "paperSize": IAlbumPaperSize[];
    "covers": IAlbumCover[];
    "paperType": IAlbumPaperType[];
    // textures: IAlbumTe;
}
export interface IPriceMap {
    [key: string]: {
        "coverPrice": number;
        "sheetPrice": number;
    }
}